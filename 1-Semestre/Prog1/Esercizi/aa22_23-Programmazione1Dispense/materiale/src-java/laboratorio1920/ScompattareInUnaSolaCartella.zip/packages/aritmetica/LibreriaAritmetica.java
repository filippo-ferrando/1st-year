package packages.aritmetica;

/**
 * Libreria con operazioni aritmetiche definite tramite iterazioni 
 * di operazioni piu' primitive.
 */
public class LibreriaAritmetica
{
  public static int piu(int x, int y) {
    int sXY = x;
    int n = y;
    while (n > 0) {
      sXY = sXY + 1; // accumula il risultato in sXY
      n = n - 1;
    }
    return sXY;
  }

  public static int meno(int m // minuendo
                        ,int s // sottraendo
                        ) {
    int   n = 0;
    int dMS = 0; // differenza tra m ed s
    
    if (m > s) {
      dMS = m;
      n = s;
      while (0 < n && n < m) {
        dMS = dMS - 1;
        n = n - 1;
      }
    }
    return dMS;
  }

  public static int per(int x, int y) {
    int mXY = 0;
    int n = y;
    while (n > 0) {

      mXY = piu(mXY, x);
      n = n - 1;
    }
    return mXY;
  }

  public static int div(int d // dividendo
                       ,int s // diviSore >= 0
                       ) {
      int qDS = 0; // quoziente
      int rDS = d; // resto

      while (rDS >= s) {
        qDS = qDS + 1; // accumula il quoziente
        rDS = meno(rDS, s); // accumula il resto
      }
    return qDS;
  }

  public static int resto(int d // dividendo
                         ,int s // diviSore >= 0 
                         ) {
      int qDS = 0; // quoziente
      int rDS = d; // resto

      while (rDS >= s) {
        qDS = qDS + 1;      // accumula il quoziente
        rDS = meno(rDS, s); // accumula il resto
      }
    return rDS;
  }

  public static int pot(int b // base
                       ,int e // esponente 
                       ) {
      int pBE = 1; // potenza

      while (e > 0) {
        pBE = per(pBE, b);  // 
        e--;
      }
    return pBE;
  }
}